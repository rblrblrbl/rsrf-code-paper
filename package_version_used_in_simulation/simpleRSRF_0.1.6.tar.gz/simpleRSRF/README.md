## simpleRSRF
Ricardo Blum

### Description
Implementation of RSRF Forests. Uses reference classes and only plain R.

### TODO


Technical stuff:
* Software tests
* Profile the code. Possible to make it faster without losing simplicity?

Be careful, this package is not extensively tested!!
